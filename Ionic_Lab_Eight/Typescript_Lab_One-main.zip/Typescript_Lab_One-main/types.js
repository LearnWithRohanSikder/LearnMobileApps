var num1 = 5;
console.log(num1);
var string1 = "Hello World!";
console.log(string1);
var flag = false;
console.log(flag);
var list = ["Hi", "Hello", "He"];
for (var i = 0; i < list.length; i++) {
    console.log("Array is " + list[i]);
}
var notSure = 5;
console.log(notSure);
var listany = [2, true, "test"];
for (var i = 0; i < listany.length; i++) {
    console.log("Array is " + listany[i]);
}
