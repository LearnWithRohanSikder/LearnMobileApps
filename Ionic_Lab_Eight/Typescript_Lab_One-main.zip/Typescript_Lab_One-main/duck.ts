function addition(value: string) {
    console.log("Value is: " + value);
    }
    
    let firstVal: number = 42;
    let secondVal: number = 1;
    let sumOfVals: string = (firstVal + secondVal).toLocaleString();
    addition(sumOfVals);
    