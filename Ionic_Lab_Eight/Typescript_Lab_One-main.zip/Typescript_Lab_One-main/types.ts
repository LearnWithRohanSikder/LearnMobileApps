let num1: number = 5;
console.log(num1);

let string1: string = "Hello World!"
console.log(string1);

let flag: boolean = false;
console.log(flag);

let list: string[] = ["Hi", "Hello", "He"];
for(let i = 0; i<list.length; i++)
{   
    console.log("Array is " + list[i]);
} 

let notSure: any = 5;
console.log(notSure);

let listany: any[] = [2, true, "test"];
for(let i = 0; i<listany.length; i++)
{   
    console.log("Array is " + listany[i]);
} 