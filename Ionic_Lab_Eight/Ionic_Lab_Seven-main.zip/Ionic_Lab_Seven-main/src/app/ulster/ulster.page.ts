import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ulster',
  templateUrl: './ulster.page.html',
  styleUrls: ['./ulster.page.scss'],
})
export class UlsterPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
