import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-connaughtcounties',
  templateUrl: './connaughtcounties.page.html',
  styleUrls: ['./connaughtcounties.page.scss'],
})
export class ConnaughtcountiesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
